# 05. 텍스트 파싱과 데이터 분석 실습 자료

이 묶음은 05장 실습용이다. 교안 본문은 온라인에서 읽고 이 폴더의 노트북·코드로 실습한다.
교안에서 말하는 '저장소 루트'는 이 ZIP에서는 requirements.txt가 있는 폴더를 뜻한다.

1. 이 폴더에서 터미널을 열고 02장에서 만든 과정용 가상환경을 활성화한다.
2. 처음 시작하거나 requirements.txt가 바뀌면 다음 명령으로 필요한 패키지를 준비한다.

```bash
python -m pip install -r requirements.txt
python -m jupyterlab
```

3. 아래 노트북을 번호 순서로 열고 과정용 커널을 선택한다.
4. 코드에서 사용하는 상대 경로를 유지하도록 notebooks·examples·fixtures 폴더를 함께 보관한다.

학습자용 Notebook의 TODO를 먼저 구현한다. 풀이 참고 파일은 notebooks/solutions에 있다.

## 이 장의 노트북

- [`05-1-normalization.ipynb`](notebooks/05-1-normalization.ipynb)
- [`05-2-split-search-replace.ipynb`](notebooks/05-2-split-search-replace.ipynb)
- [`05-3-regex-basics.ipynb`](notebooks/05-3-regex-basics.ipynb)
- [`05-4-groups-capture.ipynb`](notebooks/05-4-groups-capture.ipynb)
- [`05-5-validation.ipynb`](notebooks/05-5-validation.ipynb)
- [`05-6-datetime.ipynb`](notebooks/05-6-datetime.ipynb)
- [`05-7-numpy-array.ipynb`](notebooks/05-7-numpy-array.ipynb)
- [`05-8-pandas-dataframe.ipynb`](notebooks/05-8-pandas-dataframe.ipynb)
- [`05-9-web-log-analysis.ipynb`](notebooks/05-9-web-log-analysis.ipynb)

## 이 장만 갱신하기

교안의 해당 장 다운로드 링크에서 새 ZIP을 받아 별도 폴더에 압축 해제한다.
MANIFEST.json의 version이 같다면 실습 파일은 같은 배포본이다.
다른 장을 다시 받을 필요는 없다. 기존 폴더의 개인 풀이를 확인한 뒤 필요한 변경을 옮긴다.
교안 문구만 바뀌고 실습 파일 버전이 같다면 다시 받지 않아도 된다.
패키지 설치 버전은 로컬 환경에 따라 다를 수 있으며 version은 실습 파일 묶음을 식별한다.
